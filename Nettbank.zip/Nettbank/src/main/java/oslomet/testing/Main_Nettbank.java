package oslomet.testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main_Nettbank {

    public static void main(String[] args) {
        SpringApplication.run(Main_Nettbank.class, args);
    }

}
